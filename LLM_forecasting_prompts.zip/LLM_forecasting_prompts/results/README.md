# Results

This folder contains results from pipeline evaluation experiments. The results describe the number of pipeline predictions on the [evaluation data](../data) that fell within the defined acceptable range. Two types of results are provided in this folder: actual pipeline predictions to questions (in the format `results_{pipeline-name}.json`) and evaluation statistics (in the format `evaluation_{pipeline-name}.json`).
